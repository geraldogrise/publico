package ba.com.grisecorp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SgexApplicationTests {

	@Test
	void contextLoads() {
	}

}
