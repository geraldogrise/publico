package ba.com.grisecorp.applciation.configuration.automapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import ba.com.grisecorp.applciation.configuration.automapper.core.GenericMapper;
import ba.com.grisecorp.applciation.model.UserModel;
import ba.com.grisecorp.domain.users.User;

@Mapper
public interface UserMapper extends GenericMapper<User, UserModel> {

    UserMapper INSTANCE = Mappers.getMapper(UserMapper.class);

    @Override
    UserModel mapToModel(User entity);

    @Override
    User mapToEntity(UserModel model);
}