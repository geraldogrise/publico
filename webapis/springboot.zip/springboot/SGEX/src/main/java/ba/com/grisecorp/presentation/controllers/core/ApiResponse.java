package ba.com.grisecorp.presentation.controllers.core;

import lombok.Getter;
import lombok.Setter;
import java.util.List;
import java.util.ArrayList;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ApiResponse<T> {

    private boolean success = true;
    private List<String> erros = new ArrayList<>();
    private T data;

    // Construtor apenas com data
    public ApiResponse(T data) {
        this.data = data;
    }

    // Construtor apenas com informações (erro)
    public ApiResponse(List<String> erros) {
        this.success = false;
        this.erros = erros;
    }
}