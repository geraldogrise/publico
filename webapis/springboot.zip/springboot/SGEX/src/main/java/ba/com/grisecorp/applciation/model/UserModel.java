package ba.com.grisecorp.applciation.model;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import io.swagger.v3.oas.annotations.media.Schema;

@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Modelo de usuário")
public class UserModel {

    @Schema(description = "ID do usuário", example = "1")
    private int userId;

    @Schema(description = "Nome de usuário", example = "geraldo.grise")
    private String username;

    @Schema(description = "Email do usuário", example = "geraldogrise@hotmail.com")
    private String email;

    @Schema(description = "Telefone do usuário", example = "71993776041")
    private String phone;

    @Schema(description = "Senha do usuário", example = "Spike@888")
    private String password;
}