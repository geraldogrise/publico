package ba.com.grisecorp.applciation.interfaces;

import java.util.List;
import java.util.Optional;

import ba.com.grisecorp.applciation.model.UserModel;

public interface IUserAppService {
    
	UserModel insert(UserModel model);
    UserModel update(Integer id, UserModel model);
    UserModel delete(Integer id);
    Optional<UserModel> getById(Integer id);
    List<UserModel> getAll();
}
