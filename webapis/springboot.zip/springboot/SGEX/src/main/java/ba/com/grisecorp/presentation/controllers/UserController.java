package ba.com.grisecorp.presentation.controllers;

import ba.com.grisecorp.applciation.apps.UserAppService;
import ba.com.grisecorp.applciation.model.UserModel;
import ba.com.grisecorp.presentation.controllers.core.CoreController;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/users")
@Tag(name = "Usuários", description = "Operações relacionadas a usuários")
public class UserController extends CoreController {

    private final UserAppService userAppService;

    public UserController(UserAppService userAppService) {
        this.userAppService = userAppService;
    }

    @GetMapping
    @Operation(summary = "Lista todos os usuários")
    public ResponseEntity<?> getAll() {
        try {
            List<UserModel> users = userAppService.getAll();
            return success(users);
        } catch (Exception ex) {
            return error(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/{id}")
    @Operation(summary = "Busca um usuário pelo ID")
    public ResponseEntity<?> getById(@PathVariable Integer id) {
        try {
            Optional<UserModel> user = userAppService.getById(id);
            return user.map(this::success)
                       .orElseGet(() -> error("Usuário não encontrado", HttpStatus.NOT_FOUND));
        } catch (Exception ex) {
            return error(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping
    @Operation(summary = "Cria um novo usuário")
    public ResponseEntity<?> insert(@RequestBody UserModel model) {
        try {
            UserModel createdUser = userAppService.insert(model);
            return success(createdUser);
        } catch (Exception ex) {
            return error(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/{id}")
    @Operation(summary = "Atualiza um usuário pelo ID")
    public ResponseEntity<?> update(@PathVariable Integer id, @RequestBody UserModel model) {
        try {
            UserModel updatedUser = userAppService.update(id, model);
            return success(updatedUser);
        } catch (Exception ex) {
            return error(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Deleta um usuário pelo ID")
    public ResponseEntity<?> delete(@PathVariable Integer id) {
        try {
            UserModel deletedUser = userAppService.delete(id);
            return success(deletedUser);
        } catch (Exception ex) {
            return error(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
}