package ba.com.grisecorp.infra.data.repository;

import ba.com.grisecorp.domain.users.User;
import org.springframework.stereotype.Repository;
import ba.com.grisecorp.infra.data.repository.core.GenericRepository;

@Repository
public interface UserRepository extends GenericRepository<User, Integer> {
  
}
