package ba.com.grisecorp.domain.users.services;

import java.util.List;
import java.util.Optional;
import ba.com.grisecorp.domain.users.User;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ba.com.grisecorp.infra.data.repository.UserRepository;

@Service
@Transactional
public class UserService implements IUserService {

    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
    
    @Override
    public User insert(User user) {
       
        return userRepository.save(user);
    }
    
    @Override
    public User update(Integer id, User user) {
        // Verifica se o usuário existe
        if (!userRepository.existsById(id)) {
            throw new RuntimeException("Usuário não encontrado para atualização");
        }
        return userRepository.save(user);
    }
    
    @Override
    public User delete(Integer id) {

    	User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado para exclusão"));
        userRepository.delete(user); 
        return user;
    }
    
    @Override
    public Optional<User> getById(Integer id) {
        return userRepository.findById(id);
    }


    @Override
    public List<User> getAll() {
        return userRepository.findAll();
    }


}
