package ba.com.grisecorp.domain.users;

import lombok.Getter;
import lombok.Setter;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Getter
@Setter
@Entity
@Table(name = "T001USR")
@NoArgsConstructor
@AllArgsConstructor
public class User {

	 @Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	 @Column(name = "ID_USER")
	 private int userId;

	 @Column(name = "NM_USER", nullable = false, length = 50)
	 private String username;

	 @Column(name = "DS_EMAIL", nullable = false, length = 100)
	 private String email;

	 @Column(name = "NR_PHONE", nullable = true, length = 20)
	 private String phone;

	 @Column(name = "DS_PASSWORD", nullable = false, length = 200)
	 private String password;
}
