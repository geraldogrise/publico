package ba.com.grisecorp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EnableJpaRepositories(basePackages = "ba.com.grisecorp.infra.data.repository")
public class SgexApplication {

	public static void main(String[] args) {
		SpringApplication.run(SgexApplication.class, args);
	}

}
