package ba.com.grisecorp.applciation.configuration.automapper.core;


import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface GenericMapper<E, M> {

    default M mapToModel(E entity) {
        throw new UnsupportedOperationException("Implementar no mapper específico");
    }

    default E mapToEntity(M model) {
        throw new UnsupportedOperationException("Implementar no mapper específico");
    }
}