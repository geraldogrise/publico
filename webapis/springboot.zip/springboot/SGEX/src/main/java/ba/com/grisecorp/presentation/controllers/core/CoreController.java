package ba.com.grisecorp.presentation.controllers.core;

import java.util.List;
import java.util.Collections;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;


public class CoreController {

    protected <T> ResponseEntity<ApiResponse<T>> success(T data) {
        ApiResponse<T> response = new ApiResponse<>(data);
        return ResponseEntity.ok(response);
    }

    /**
     * Retorna uma resposta de sucesso com uma lista de objetos
     */
    protected <T> ResponseEntity<ApiResponse<List<T>>> success(List<T> data) {
        ApiResponse<List<T>> response = new ApiResponse<>(data);
        return ResponseEntity.ok(response);
    }

    /**
     * Retorna uma resposta de erro
     */
    protected <T> ResponseEntity<ApiResponse<T>> error(String message, HttpStatus status) {
        ApiResponse<T> response = new ApiResponse<>();
        response.setSuccess(false);
        response.setErros(Collections.singletonList(message));
        return new ResponseEntity<>(response, status);
    }

    /**
     * Retorna uma resposta de erro com múltiplas mensagens
     */
    protected <T> ResponseEntity<ApiResponse<T>> error(List<String> messages, HttpStatus status) {
        ApiResponse<T> response = new ApiResponse<>();
        response.setSuccess(false);
        response.setErros(messages);
        return new ResponseEntity<>(response, status);
    }
}