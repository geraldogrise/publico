package ba.com.grisecorp.domain.users.services;

import java.util.List;
import java.util.Optional;

import ba.com.grisecorp.domain.users.User;

public interface IUserService {

    // Inserir um novo usuário
    User insert(User user);

    // Atualizar um usuário existente
    User update(Integer id, User user);
    
    User delete(Integer id);

    // Obter usuário pelo ID
    Optional<User> getById(Integer id);

    // Listar todos os usuários
    List<User> getAll();
}