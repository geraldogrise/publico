package ba.com.grisecorp.applciation.configuration;

import org.springframework.context.annotation.Configuration;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;

@Configuration
@OpenAPIDefinition(
    info = @Info(
        title = "SGEX API",
        version = "v1",
        description = "Documentação da API SGEX"
    )
)
public class SwaggerConfiguration {
}