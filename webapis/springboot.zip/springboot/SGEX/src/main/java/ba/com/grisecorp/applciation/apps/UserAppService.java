package ba.com.grisecorp.applciation.apps;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import jakarta.transaction.Transactional;
import ba.com.grisecorp.domain.users.User;
import org.springframework.stereotype.Service;
import ba.com.grisecorp.applciation.model.UserModel;
import ba.com.grisecorp.domain.users.services.UserService;
import ba.com.grisecorp.applciation.interfaces.IUserAppService;
import ba.com.grisecorp.applciation.configuration.automapper.UserMapper;


@Service
@Transactional
public class UserAppService implements IUserAppService {

    private final UserService userService;
    private final UserMapper mapper = UserMapper.INSTANCE;

    public UserAppService(UserService userService) {
        this.userService = userService;
    }

    @Override
    public UserModel insert(UserModel model) {
        User entity = mapper.mapToEntity(model);
        entity = userService.insert(entity);
        return mapper.mapToModel(entity);
    }

    @Override
    public UserModel update(Integer id, UserModel model) {
        User entity = userService.getById(id)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
        entity = userService.update(id, entity);
        return mapper.mapToModel(entity);
    }

    @Override
    public UserModel delete(Integer id) {
        User entity = userService.delete(id);
        return mapper.mapToModel(entity);
    }

    @Override
    public Optional<UserModel> getById(Integer id) {
        return userService.getById(id).map(mapper::mapToModel);
    }

    @Override
    public List<UserModel> getAll() {
        return userService.getAll().stream()
                .map(mapper::mapToModel)
                .collect(Collectors.toList());
    }
}