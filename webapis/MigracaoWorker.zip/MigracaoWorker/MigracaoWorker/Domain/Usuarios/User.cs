﻿using MigracaoWorker.Domain.Core;

namespace MigracaoWorker.Domain.Usuarios
{
    public class User : EntityCore<User>
    {
        public int Id { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public string CPF { get; set; }
        public string Matricula { get; set; }
        public string Nome { get; set; }
        public string CNPJ { get; set; }
        public string Status { get; set; }

        public override bool IsValid()
        {
            return true;
        }
    }
}
