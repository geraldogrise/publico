﻿using Azure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MigracaoWorker.Domain.Usuarios.Services
{
    public interface IUserService : IDisposable
    {
        List<User> GetByStatus(bool status, int page, int pageSize);
    }
}
