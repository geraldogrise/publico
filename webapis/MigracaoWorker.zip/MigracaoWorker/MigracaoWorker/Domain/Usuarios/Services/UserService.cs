﻿using Azure;
using Microsoft.Graph.Models;
using MigracaoWorker.Domain.Usuarios.Repository;

namespace MigracaoWorker.Domain.Usuarios.Services
{
   
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;

        public UserService(IUserRepository userRepository) 
        {
            _userRepository = userRepository;
        }
        public List<User> GetByStatus(bool status, int page, int pageSize)
   {
            if (page <= 0) page = 1;
            if (pageSize <= 0) pageSize = 10;
            return _userRepository
            .Find(x => x.Status.Equals(status))
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToList();
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        protected virtual void Dispose(bool disposing)
        {
            _userRepository.Dispose();
        }
    }
}
