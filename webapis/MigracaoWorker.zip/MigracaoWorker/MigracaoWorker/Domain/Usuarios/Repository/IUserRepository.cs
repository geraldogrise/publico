﻿using MigracaoWorker.Domain.Interfaces;


namespace MigracaoWorker.Domain.Usuarios.Repository
{
    public interface IUserRepository : IRepository<User>
    {
       
    }
}
