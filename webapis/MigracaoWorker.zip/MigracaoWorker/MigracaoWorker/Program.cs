using Microsoft.EntityFrameworkCore;
using MigracaoWorker;
using MigracaoWorker.Data.Context;
using MigracaoWorker.Data.Repository;
using MigracaoWorker.Domain.Usuarios.Repository;
using MigracaoWorker.Domain.Usuarios.Services;
using MigracaoWorker.Infra.AzureB2C;

var builder = Host.CreateApplicationBuilder(args);

var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");


// Registra o DbContext com SQL Server (ou outro provider que estiver usando)
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(connectionString));
// Registra o servi�o na inje��o de depend�ncia
builder.Services.AddSingleton<GraphAuthProvider>();

builder.Services.AddScoped<IUserRepository, UserRepository>(); // sua implementa��o
builder.Services.AddScoped<IUserService, UserService>();


// Registra o Worker que depende do servi�o
builder.Services.AddHostedService<Worker>();

var host = builder.Build();
host.Run();