﻿using MigracaoWorker.Domain.Usuarios.Services;
using MigracaoWorker.Infra.AzureB2C;
using Microsoft.Graph.Models;
using Microsoft.Extensions.Logging;
using Azure;

namespace MigracaoWorker
{
    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;
        private readonly IServiceScopeFactory _scopeFactory;
        private readonly IConfiguration _configuration;
        private readonly GraphAuthProvider _graphAuthProvider;

        public Worker(
            ILogger<Worker> logger,
            IServiceScopeFactory scopeFactory,
            IConfiguration configuration,
            GraphAuthProvider graphAuthProvider)
        {
            _logger = logger;
            _scopeFactory = scopeFactory;
            _configuration = configuration;
            _graphAuthProvider = graphAuthProvider;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("Iniciando migração de usuários ativos...");

            var graphClient = _graphAuthProvider.GetGraphClient();
            var page = 1;
            var pageSize = 10;

            using var scope = _scopeFactory.CreateScope();
            var userService = scope.ServiceProvider.GetRequiredService<IUserService>();

            while (!stoppingToken.IsCancellationRequested)
            {
                var users = userService.GetByStatus(true, page, pageSize);

                if (users == null || users.Count == 0)
                    break;

                foreach (var user in users)
                {
                    try
                    {
                        var identity = new ObjectIdentity
                        {
                            SignInType = "emailAddress",
                            Issuer = _configuration["AzureAdB2C:TenantDomain"],
                            IssuerAssignedId = user.Email
                        };

                        var graphUser = new User
                        {
                            AccountEnabled = true,
                            DisplayName = user.Nome,
                            Identities = new List<ObjectIdentity> { identity },
                            PasswordProfile = new PasswordProfile
                            {
                                ForceChangePasswordNextSignIn = true,
                                Password = GenerateTemporaryPassword()
                            },
                            PasswordPolicies = "DisablePasswordExpiration"
                        };

                        graphUser.AdditionalData = new Dictionary<string, object>
                        {
                            { "extension_cpf", user.CPF },
                            { "extension_cnpj", user.CNPJ },
                            { "extension_matricula", user.Matricula },
                            { "mobilePhone", user.PhoneNumber }
                        };

                        await graphClient.Users.PostAsync(graphUser);
                        _logger.LogInformation("Usuário {Email} migrado com sucesso!", user.Email);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Erro ao migrar o usuário {Email}", user.Email);
                    }
                }

                page++;
            }

            _logger.LogInformation("Migração finalizada.");
        }

        private string GenerateTemporaryPassword() => "SenhaTemp@123";
    }
}
