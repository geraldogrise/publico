﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MigracaoWorker.Data.Core;
using MigracaoWorker.Domain.Usuarios;


namespace MigracaoWorker.Data.Mappings
{
    public class UserMapping : MappingCore<User>
    {
        public void Configure(EntityTypeBuilder<User> builder)
        {
            builder.ToTable("Usuarios");

            builder.HasKey(u => u.Id);

            builder.Property(u => u.Id).HasMaxLength(36);
            builder.Property(u => u.UserName).HasMaxLength(100);
            builder.Property(u => u.Email).HasMaxLength(150);
            builder.Property(u => u.PhoneNumber).HasMaxLength(20);
            builder.Property(u => u.CPF).HasMaxLength(14);
            builder.Property(u => u.CNPJ).HasMaxLength(18);
            builder.Property(u => u.Matricula).HasMaxLength(50);
            builder.Property(u => u.Nome).HasMaxLength(150);
            base.Map(builder);
        }
    }
}
