﻿using MigracaoWorker.Data.Core;
using MigracaoWorker.Data.Context;

using MigracaoWorker.Domain.Usuarios.Repository;
using System.Linq.Expressions;
using MigracaoWorker.Domain.Interfaces;
using MigracaoWorker.Domain.Usuarios;


namespace MigracaoWorker.Data.Repository
{
    public class UserRepository : Repository<User>, IUserRepository
    {
        public UserRepository(AppDbContext context) : base(context) { }
    }
}
