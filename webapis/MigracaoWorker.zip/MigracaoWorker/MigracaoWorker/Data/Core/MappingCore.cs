﻿using FluentValidation.Results;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MigracaoWorker.Data.Core.Extension;
using MigracaoWorker.Domain.Core;
using System.Reflection.Emit;

namespace MigracaoWorker.Data.Core
{
    public class MappingCore<T> : EntityTypeConfiguration<T> where T : EntityCore<T>
    {
        public override void Map(EntityTypeBuilder<T> builder)
        {
            builder.Ignore(x => x.ClassLevelCascadeMode);
            builder.Ignore(x => x.RuleLevelCascadeMode);
            builder.Ignore(x => x.ValidationResult);
        }
    }
}
