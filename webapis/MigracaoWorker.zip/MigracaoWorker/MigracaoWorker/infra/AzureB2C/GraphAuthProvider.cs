﻿using Azure.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.Graph;

namespace MigracaoWorker.Infra.AzureB2C
{
    public class GraphAuthProvider
    {
        private readonly string _clientId;
        private readonly string _tenantId;
        private readonly string _clientSecret;

        public GraphAuthProvider(IConfiguration configuration)
        {
            _clientId = configuration["AzureAdB2C:ClientId"];
            _tenantId = configuration["AzureAdB2C:TenantId"];
            _clientSecret = configuration["AzureAdB2C:ClientSecret"];
        }

        public GraphServiceClient GetGraphClient()
        {
            var options = new ClientSecretCredentialOptions
            {
                AuthorityHost = AzureAuthorityHosts.AzurePublicCloud
            };

            var credential = new ClientSecretCredential(_tenantId, _clientId, _clientSecret, options);

            return new GraphServiceClient(credential);
        }
    }
}
