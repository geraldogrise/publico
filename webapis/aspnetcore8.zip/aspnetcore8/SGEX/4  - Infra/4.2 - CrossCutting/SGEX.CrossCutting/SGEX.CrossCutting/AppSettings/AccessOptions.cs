﻿namespace SGEX.CrossCutting.AppSettings
{
    public class AccessOptions
    {
        public string Enviroment { get; set; }
        public string FileServer { get; set; }
    }
}
