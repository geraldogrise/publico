﻿namespace SGEX.CrossCutting.Swagger
{
    public class SwaggerOptions
    {
        public string Title { get; set; }

        public string Description { get; set; }

        public string Version { get; set; }
    }
}
