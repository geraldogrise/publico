﻿using MediatR;
using Microsoft.Extensions.DependencyInjection;
using SGEX.Application.Apps;
using SGEX.Application.Interfaces;
using SGEX.Data.Context;
using SGEX.Data.Repository;
using SGEX.Domain.Aggregates.Users.Repository;
using SGEX.Domain.Aggregates.Users.Services;
using SGEX.Domain.Notification;


namespace SGEX.CrossCuttingIoC
{
    public static class BootStrapper
    {
        public static void RegisterServices(IServiceCollection services)
        {
            // Application
            services.AddScoped<IUserAppService, UserAppService>();

            // Domain
            services.AddScoped<INotificationHandler<DomainNotification>, DomainNotificationHandler>();
            services.AddScoped<IUserService, UserService>();

            // Data
            services.AddScoped<DatabaseContext>();
            services.AddScoped<IUserRepository, UserRepository>();
        }
    }
}
