﻿using SGEX.Data.Context;
using SGEX.Data.Core.Repository;
using SGEX.Domain.Aggregates.Users;
using SGEX.Domain.Aggregates.Users.Repository;

namespace SGEX.Data.Repository
{
    public class UserRepository : Repository<User>, IUserRepository
    {
        public UserRepository(DatabaseContext context) : base(context)
        {
        }
    }
}
