﻿using Microsoft.EntityFrameworkCore;
using SGEX.Data.Context;
using SGEX.Domain.Aggregates.Core;
using SGEX.Domain.Interfaces;
using System.Linq.Expressions;


namespace SGEX.Data.Core.Repository
{
    public class Repository<TEntity> : IRepository<TEntity> where TEntity : EntityCore<TEntity>
    {
        protected readonly DatabaseContext _context;
        protected readonly DbSet<TEntity> _dbSet;

        public Repository(DatabaseContext context)
        {
            _context = context;
            _dbSet = _context.Set<TEntity>();
        }

        #region Add
        public void Add(TEntity entity)
        {
            _dbSet.Add(entity);
        }

        public async Task AddAsync(TEntity entity)
        {
            await _dbSet.AddAsync(entity);
        }

        public void Add(IEnumerable<TEntity> entities)
        {
            _dbSet.AddRange(entities);
        }

        public async Task AddAsync(IEnumerable<TEntity> entities)
        {
            await _dbSet.AddRangeAsync(entities);
        }
        #endregion

        #region Get
        public TEntity GetById(params object[] ids)
        {
            return _dbSet.Find(ids);
        }

        public async Task<TEntity> GetByIdAsync(params object[] ids)
        {
            return await _dbSet.FindAsync(ids);
        }

        public IEnumerable<TEntity> GetAll()
        {
            return _dbSet.AsNoTracking().ToList();
        }

        public async Task<IEnumerable<TEntity>> GetAllAsync()
        {
            return await _dbSet.AsNoTracking().ToListAsync();
        }

        public IEnumerable<TEntity> Find(Expression<Func<TEntity, bool>> predicate)
        {
            return _dbSet.AsNoTracking().Where(predicate).ToList();
        }

        public async Task<IEnumerable<TEntity>> FindAsync(Expression<Func<TEntity, bool>> predicate)
        {
            return await _dbSet.AsNoTracking().Where(predicate).ToListAsync();
        }
        #endregion

        #region Update
        public void Update(TEntity entity)
        {
            _dbSet.Update(entity);
        }

        public async Task UpdateAsync(TEntity entity)
        {
            await Task.Run(() => _dbSet.Update(entity));
        }

        public void Update(IEnumerable<TEntity> entities)
        {
            _dbSet.UpdateRange(entities);
        }

        public async Task UpdateAsync(IEnumerable<TEntity> entities)
        {
            await Task.Run(() => _dbSet.UpdateRange(entities));
        }

        public void Update(TEntity current, TEntity updated)
        {
            _context.Entry(current).CurrentValues.SetValues(updated);
        }

        public async Task UpdateAsync(TEntity current, TEntity updated)
        {
            await Task.Run(() => _context.Entry(current).CurrentValues.SetValues(updated));
        }
        #endregion

        #region Remove
        public void Remove(params object[] ids)
        {
            var entity = GetById(ids);
            if (entity != null)
                _dbSet.Remove(entity);
        }

        public async Task RemoveAsync(params object[] ids)
        {
            var entity = await GetByIdAsync(ids);
            if (entity != null)
                _dbSet.Remove(entity);
        }

        public void Remove(TEntity entity)
        {
            _dbSet.Remove(entity);
        }

        public Task RemoveAsync(TEntity entity)
        {
            return Task.Run(() => _dbSet.Remove(entity));
        }

        public void Remove(IEnumerable<TEntity> entities)
        {
            _dbSet.RemoveRange(entities);
        }

        public Task RemoveAsync(IEnumerable<TEntity> entities)
        {
            return Task.Run(() => _dbSet.RemoveRange(entities));
        }
        #endregion

        #region Save
        public int SaveChanges()
        {
            return _context.SaveChanges();
        }

        public async Task<int> SaveChangesAsync()
        {
            return await _context.SaveChangesAsync();
        }
        #endregion

        #region Dispose
        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
                _context.Dispose();
        }
        #endregion
    }
}
