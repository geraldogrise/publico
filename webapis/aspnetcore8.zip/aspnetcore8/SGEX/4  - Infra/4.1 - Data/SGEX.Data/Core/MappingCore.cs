﻿using SGEX.Data.Core.Extensions;
using SGEX.Domain.Aggregates.Core;
using Microsoft.EntityFrameworkCore.Metadata.Builders;


namespace SGEX.Data.Core
{
    public class MappingCore<T> : EntityTypeConfiguration<T> where T : EntityCore<T>
    {
        public override void Map(EntityTypeBuilder<T> builder)
        {
            builder.Ignore(x => x.ValidationResult);
            builder.Ignore(x => x.ClassLevelCascadeMode);
            builder.Ignore(x => x.RuleLevelCascadeMode);
        }
    }
}
