﻿using SGEX.Data.Core;
using SGEX.Domain.Aggregates.Users;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;


namespace SGEX.Data.Mappings
{
    public class UserMap : MappingCore<User>
    {
        public override void Map(EntityTypeBuilder<User> builder)
        {
            builder.ToTable("T001USR"); // 👈 Nome da tabela no banco

            builder.HasKey(x => x.UserId);

            builder.Property(x => x.UserId)
                .HasColumnName("ID_USER")
                .IsRequired()
                .ValueGeneratedOnAdd();

            builder.Property(x => x.Username)
                   .HasColumnName("NM_USER")
                   .IsRequired()
                   .IsUnicode(false)
                   .HasColumnType("varchar")
                   .HasMaxLength(50);

            builder.Property(x => x.Email)
                   .HasColumnName("DS_EMAIL")
                   .IsRequired()
                   .IsUnicode(false)
                   .HasColumnType("varchar")
                   .HasMaxLength(100);

            builder.Property(x => x.Phone)
                   .HasColumnName("NR_PHONE")
                   .IsUnicode(false)
                   .HasColumnType("varchar")
                   .HasMaxLength(20);

            builder.Property(x => x.Password)
                   .HasColumnName("DS_PASSWORD")
                   .IsRequired()
                   .IsUnicode(false)
                   .HasColumnType("varchar")
                   .HasMaxLength(200);

            // Chama configuração base (se MappingCore tiver mais regras genéricas)
            base.Map(builder);
        }
    }
}
