﻿using SGEX.Domain.Aggregates.Core;

namespace SGEX.Domain.Aggregates.Users
{
    public class User : EntityCore<User>
    {
        public int UserId { get; set; }
        public string Username { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;

       
    }
}
