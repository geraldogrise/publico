﻿using MediatR;
using SGEX.Domain.Services;
using SGEX.Domain.Aggregates.Users.Repository;

namespace SGEX.Domain.Aggregates.Users.Services
{
    public class UserService : Service, IUserService, IDisposable
    {
        private readonly IUserRepository _userRepository;

        public UserService(IMediator mediator, IUserRepository userRepository) : base(mediator)
        {
            _userRepository = userRepository;
        }

        public async Task<User> Insert(User user)
        {
            try
            {
                if (!user.IsValid())
                {
                  
                }
                await _userRepository.AddAsync(user);
                await _userRepository.SaveChangesAsync();
                return user;

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
          
        }

        public async Task<User> Update(int id, User user)
        {
            if (!user.IsValid())
            {

            }
            user.UserId = id;
            _userRepository.Update(user);
            await _userRepository.SaveChangesAsync();
            return user;
        }

        public async Task<User> Delete(int id)
        {
            var user = await FindById(id);
            if (user != null)
            {
                _userRepository.Remove(user);
                await _userRepository.SaveChangesAsync();
                return user;
            }
            return null;
           
        }

        public async Task<User?> FindById(int id)
        {
            return await Task.Run(() =>
                _userRepository.Find(x => x.UserId == id).FirstOrDefault()
            );
        }

        public async Task<List<User>> GetAll()
        {
            return await Task.Run(() =>
                _userRepository.GetAll().ToList()
            );
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        protected virtual void Dispose(bool disposing)
        {
            _userRepository.Dispose();
        }
    }
}
