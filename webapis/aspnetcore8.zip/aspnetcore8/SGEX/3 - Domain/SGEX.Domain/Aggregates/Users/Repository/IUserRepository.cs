﻿using SGEX.Domain.Interfaces;

namespace SGEX.Domain.Aggregates.Users.Repository
{
    public interface IUserRepository : IRepository<User>
    {
    }
}
