﻿namespace SGEX.Domain.Aggregates.Users.Services
{
    public interface IUserService : IDisposable
    {
        Task<User> Insert(User user);

        Task<User> Update(int id, User user);

        Task<User> Delete(int id);

        Task<User?> FindById(int id);

        Task<List<User>> GetAll();
    }
}
