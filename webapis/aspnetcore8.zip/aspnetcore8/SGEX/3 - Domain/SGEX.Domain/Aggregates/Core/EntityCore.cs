﻿using FluentValidation;
using FluentValidation.Results;

namespace SGEX.Domain.Aggregates.Core
{
    public abstract class EntityCore<T> : AbstractValidator<T> where T : EntityCore<T>
    {
        public ValidationResult ValidationResult { get; protected set; }

        protected EntityCore()
        {
            ValidationResult = new ValidationResult();
        }

        public bool IsValid()
        {
            // Executa validação da própria entidade
            ValidationResult = Validate(this as T);
            return ValidationResult.IsValid;
        }

        public void AddValidationResult(ValidationResult validationResult)
        {
            if (validationResult != null)
                foreach (var error in validationResult.Errors)
                    ValidationResult.Errors.Add(error);
        }
    }
}
