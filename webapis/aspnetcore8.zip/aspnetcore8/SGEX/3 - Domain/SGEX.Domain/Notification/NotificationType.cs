﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGEX.Domain.Notification
{
    public enum NotificationType
    {
        Success,
        Information,
        Warning,
        Error
    }
}
