﻿using System.Linq.Expressions;
using SGEX.Domain.Aggregates.Core;

namespace SGEX.Domain.Interfaces
{
    public interface IRepository<TEntity> : IDisposable where TEntity : EntityCore<TEntity>
    {
        // Adicionar
        void Add(TEntity entity);
        Task AddAsync(TEntity entity);

        void Add(IEnumerable<TEntity> entities);
        Task AddAsync(IEnumerable<TEntity> entities);

        // Buscar
        TEntity GetById(params object[] ids);
        Task<TEntity> GetByIdAsync(params object[] ids);

        IEnumerable<TEntity> GetAll();
        Task<IEnumerable<TEntity>> GetAllAsync();

        IEnumerable<TEntity> Find(Expression<Func<TEntity, bool>> predicate);
        Task<IEnumerable<TEntity>> FindAsync(Expression<Func<TEntity, bool>> predicate);

        // Atualizar
        void Update(TEntity entity);
        Task UpdateAsync(TEntity entity);

        void Update(IEnumerable<TEntity> entities);
        Task UpdateAsync(IEnumerable<TEntity> entities);

        void Update(TEntity current, TEntity updated);
        Task UpdateAsync(TEntity current, TEntity updated);

        // Remover
        void Remove(params object[] ids);
        Task RemoveAsync(params object[] ids);

        void Remove(TEntity entity);
        Task RemoveAsync(TEntity entity);

        void Remove(IEnumerable<TEntity> entities);
        Task RemoveAsync(IEnumerable<TEntity> entities);

        // Persistência
        int SaveChanges();
        Task<int> SaveChangesAsync();
    }
}
