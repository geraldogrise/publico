CREATE TABLE T001USR (
    ID_USER INT IDENTITY(1,1) NOT NULL PRIMARY KEY, -- Auto incremento (ValueGeneratedOnAdd)

    NM_USER VARCHAR(50) NOT NULL,       -- Username
    DS_EMAIL VARCHAR(100) NOT NULL,     -- Email
    NR_PHONE VARCHAR(20) NULL,          -- Telefone (não está como obrigatório no mapping)
    DS_PASSWORD VARCHAR(200) NOT NULL   -- Senha
);