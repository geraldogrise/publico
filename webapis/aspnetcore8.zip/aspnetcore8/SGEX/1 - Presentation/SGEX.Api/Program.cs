using Microsoft.AspNetCore.Hosting;
using SGEX.Api.Configuration;
using SGEX.Domain.Services;

var builder = WebApplication.CreateBuilder(args);

var assemblies = AppDomain.CurrentDomain.GetAssemblies()
    .Where(a => !a.IsDynamic && a.FullName.StartsWith("SGEX"))
    .ToArray();

// Registro gen�rico do MediatR
builder.Services.AddMediatR(cfg =>
{
    cfg.RegisterServicesFromAssemblies(assemblies);
});

// Add services to the container.

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddAcessService(builder.Configuration);
builder.Services.AddAutoMapperSetup();
builder.Services.AddDIConfiguration();
builder.Services.AddSwaggerConfig(builder.Configuration);

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
