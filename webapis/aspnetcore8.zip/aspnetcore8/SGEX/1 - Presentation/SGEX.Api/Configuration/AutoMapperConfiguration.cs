﻿using Microsoft.Extensions.DependencyInjection;
using SGEX.Application.AutoMapper;

namespace SGEX.Api.Configuration
{
    public static class AutoMapperConfiguration
    {
        public static void AddAutoMapperSetup(this IServiceCollection services)
        {
            if (services == null)
                throw new ArgumentNullException(nameof(services));

            AutoMapperConfig.RegisterMappings(services);
        }
    }
}
