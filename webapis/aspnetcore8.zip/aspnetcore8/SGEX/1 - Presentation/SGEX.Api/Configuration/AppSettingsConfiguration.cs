﻿using Microsoft.Extensions.Options;
using SGEX.CrossCutting.AppSettings;

namespace SGEX.Api.Configuration
{
    public static class AppSettingsConfiguration
    {
        public static void AddAcessService(this IServiceCollection services, IConfiguration configuration)
        {
            if (services == null) throw new ArgumentNullException(nameof(services));

            var AcessoOptions = new AccessOptions();
            new ConfigureFromConfigurationOptions<AccessOptions>(configuration.GetSection("AccessConfiguration"))
                .Configure(AcessoOptions);

            services.AddSingleton(AcessoOptions);
        }
    }
}
