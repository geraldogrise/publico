﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using SGEX.Api.Controllers.Core;
using SGEX.Application.Interfaces;
using SGEX.Application.ViewModels;
using SGEX.Domain.Notification;

namespace SGEX.API.Services.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : BaseController
    {
        private readonly IUserAppService _userAppService;

        public UserController(INotificationHandler<DomainNotification> notifications,
                              IMediator mediator,
                              IUserAppService userAppService)
            : base(notifications, mediator)
        {
            _userAppService = userAppService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var users = await _userAppService.GetAll();
                return Response(users);
            }
            catch (Exception ex)
            {
                RaiseError(ex.Message);
                return Response(null, ex.Message, null);
            }
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById(int id)
        {
            try
            {
                var user = await _userAppService.FindById(id);
                return Response(user);
            }
            catch (Exception ex)
            {
                RaiseError(ex.Message);
                return Response(null, ex.Message, null);
            }
        }

        [HttpPost]
        public async Task<IActionResult> Insert([FromBody] UserModel userModel)
        {
            try
            {
                if (userModel == null)
                    RaiseError("Dados inválidos!");

                var user = await _userAppService.Insert(userModel);
                return Response(user);
            }
            catch (Exception ex)
            {
                RaiseError(ex.Message);
                return Response(null, ex.Message, null);
            }
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, [FromBody] UserModel userModel)
        {
            try
            {
                if (userModel == null)
                    RaiseError("Dados inválidos!");

                var user = await _userAppService.Update(id, userModel);
                return Response(user);
            }
            catch (Exception ex)
            {
                RaiseError(ex.Message);
                return Response(null, ex.Message, null);
            }
        }

        [HttpDelete]
        public async Task<IActionResult> Delete([FromQuery] int id)
        {
            try
            {
                var user = await _userAppService.Delete(id);
                return Response(user);
            }
            catch (Exception ex)
            {
                RaiseError(ex.Message);
                return Response(null, ex.Message, null);
            }
        }
    }
}
