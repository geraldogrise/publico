﻿using AutoMapper;
using MediatR;
using SGEX.Application.Apps.Core;
using SGEX.Application.Interfaces;
using SGEX.Application.ViewModels;
using SGEX.Domain.Aggregates.Users.Services;
using SGEX.Domain.Aggregates.Users;
using SGEX.Domain.Notification;


namespace SGEX.Application.Apps
{
    public class UserAppService : ApplicationService, IUserAppService
    {
        private readonly IMapper _mapper;
        private readonly IUserService _userService;

        public UserAppService(IMediator mediator,
                              INotificationHandler<DomainNotification> notifications,
                              IMapper mapper,
                              IUserService userService)
            : base(mediator, notifications)
        {
            _mapper = mapper;
            _userService = userService;
        }


        public async Task<UserModel> Insert(UserModel userModel)
        {
            var user = _mapper.Map<User>(userModel);
            user = await _userService.Insert(user);
            return _mapper.Map<UserModel>(user);
        }

        public async Task<UserModel> Update(int id, UserModel userModel)
        {
            var user = _mapper.Map<User>(userModel);
            user = await _userService.Update(id, user);
            return _mapper.Map<UserModel>(user);
        }

        public async Task<UserModel?> Delete(int id)
        {
            var user = await _userService.Delete(id);
            return user != null ? _mapper.Map<UserModel>(user) : null;
        }

        public async Task<UserModel?> FindById(int id)
        {
            var user = await _userService.FindById(id);
            return user != null ? _mapper.Map<UserModel>(user) : null;
        }

        public async Task<List<UserModel>> GetAll()
        {
            var users = await _userService.GetAll();
            return _mapper.Map<List<UserModel>>(users);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        protected virtual void Dispose(bool disposing)
        {
            _userService.Dispose();
        }

    }
}
