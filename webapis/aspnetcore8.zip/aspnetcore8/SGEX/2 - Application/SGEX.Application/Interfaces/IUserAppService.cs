﻿using SGEX.Application.ViewModels;
using SGEX.Domain.Aggregates.Users;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGEX.Application.Interfaces
{
    public interface IUserAppService
    {
        Task<UserModel> Insert(UserModel userModel);

        Task<UserModel> Update(int id, UserModel userModel);

        Task<UserModel> Delete(int id);

        Task<UserModel?> FindById(int id);

        Task<List<UserModel>> GetAll();
    }
}
