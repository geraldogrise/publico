﻿using AutoMapper;
using SGEX.Application.ViewModels;
using SGEX.Domain.Aggregates.Users;

namespace SGEX.Application.AutoMapper
{
    public class ViewModelToDomainMappingProfile : Profile
    {
        public ViewModelToDomainMappingProfile()
        {
            CreateMap<UserModel, User>();
        }
    }
}
