﻿using AutoMapper;
using SGEX.Application.ViewModels;
using SGEX.Domain.Aggregates.Users;

namespace SGEX.Application.AutoMapper
{
    public class DomainToViewModelMappingProfile : Profile
    {
        public DomainToViewModelMappingProfile()
        {
            CreateMap<User, UserModel>();
        }
    }
}
