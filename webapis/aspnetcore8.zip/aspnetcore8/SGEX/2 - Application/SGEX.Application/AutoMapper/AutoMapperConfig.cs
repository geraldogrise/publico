﻿using AutoMapper;
using AutoMapper.Internal;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace SGEX.Application.AutoMapper
{
    public static class AutoMapperConfig
    {
        public static void RegisterMappings(this IServiceCollection services)
        {
            // Adiciona AutoMapper com todos os perfis do assembly
            services.AddAutoMapper(cfg =>
            {
                cfg.AddProfile<DomainToViewModelMappingProfile>();
                cfg.AddProfile<ViewModelToDomainMappingProfile>();


            }, typeof(AutoMapperConfig).Assembly);

            // O IMapper será resolvido via DI automaticamente
        }
    }
}
